# FixItProof MVP

A professional, responsive landing page + diagnosis-flow prototype for FixItProof.

## Files
- index.html — main website
- styles.css — responsive styling
- script.js — demo diagnosis interaction

## What is included
- Professional automotive-tech branding
- Hero section and CTA
- Vehicle information form
- Symptom description field
- Photo/video upload UI
- Demo analysis result
- Features section
- Pricing/monetization section
- Mobile responsive layout

## To make it a real product
Connect the diagnosis form to a backend/API, user authentication, payments, repair-cost data, vehicle data, and a real diagnostic model. Add privacy/terms pages before collecting customer data.
